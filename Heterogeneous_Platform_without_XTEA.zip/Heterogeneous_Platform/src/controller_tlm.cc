#include "controller_tlm.hh"

controller_tlm::controller_tlm(sc_module_name name) : sc_module(name)
{
    initiator_socket_transactor(*this);
    SC_THREAD(run);

    m_qk.set_global_quantum(sc_time(500, SC_NS));
    m_qk.reset();
}

void controller_tlm::run()
{
    // Inizializzazione tempo locale
    sc_time local_time = m_qk.get_local_time();

    // Dati per scambio transazioni
    struct packet_transactor packet_data;
    tlm::tlm_generic_payload packet_payload;

    // Inizializzazione threshold
    thresh = CONTROLLER_INITIAL_THRESHOLD;

    while(true) {

        // Prima leggo livello acqua
        packet_payload.set_read();
        packet_payload.set_data_ptr((unsigned char*) &packet_data);
        initiator_socket_transactor->b_transport(packet_payload, local_time);
        double acqua = packet_data.livello_acqua;

        // Aspetto
        wait(100, sc_core::SC_MS);

        // Applico il calcolo al pacchetto
        if(acqua < 5.0) {
            thresh *= 1.1;
            packet_data.threshold = thresh;
            packet_data.comando = OPEN;

        } else if(acqua > 8.8) {
            thresh *= 0.7;
            packet_data.threshold = thresh;
            packet_data.comando = CLOSE;

        } else {
            packet_data.threshold = thresh;
            packet_data.comando = IDLE;
        }        

        // Poi applico il controllo alla valvola
        packet_payload.set_write();
        packet_payload.set_data_ptr((unsigned char*) &packet_data);
        initiator_socket_transactor->b_transport(packet_payload, local_time);

        // Infine aggiorno QK
        m_qk.set(local_time);
        if (m_qk.need_sync()) {
            m_qk.sync();
        }
    }
}





