#include "common.hh"
#include "controller_tlm.hh"
#include "transactor.hh"
#include "valve.hh"
#include "valve_if.hh"
#include "watertank.hh"
#include "watertank_if.hh"

int sc_main(int argc, char* argv[])
{
    // Inizio settando la risoluzione della simulazione
    sc_core::sc_set_time_resolution(1.0, sc_core::SC_US);

    // Moduli
    controller_tlm c("controller_tlm");
    transactor t("transactor");
    valve_if vif("valve_if");
    valve v("valve");
    watertank wt("watertank");
    watertank_if wtif("watertank_if");

    // Connessione moduli AMS
    sca_tdf::sca_signal<double> sig_livello_acqua, sig_threshold, sig_apertura;
    sca_tdf::sca_signal<int> sig_comando;
    vif.comando_ams(sig_comando);       // out
    vif.threshold_ams(sig_threshold);   // out
    v.comando(sig_comando);             // in
    v.threshold(sig_threshold);         // in
    v.apertura(sig_apertura);           // out
    wt.in(sig_apertura);                // in
    wt.out(sig_livello_acqua);          // out
    wtif.livello_acqua_ams(sig_livello_acqua);

    // Connessione dell'interfaccia della valvola + interfaccia serbatoio col transattore
    sc_core::sc_signal<int> sig_rtl_comando;
    sc_core::sc_signal<double> sig_rtl_threshold, sig_rtl_livello_acqua;
    t.comando(sig_rtl_comando);
    t.threshold(sig_rtl_threshold);
    t.livello_acqua(sig_rtl_livello_acqua);
    vif.comando_rtl(sig_rtl_comando);
    vif.threshold_rtl(sig_rtl_threshold);
    wtif.livello_acqua_rtl(sig_rtl_livello_acqua);

    // Connessione controllore e transattore
    c.initiator_socket_transactor(t.target_socket);
    
    // File di trace
    sca_util::sca_trace_file* trace = sca_util::sca_create_vcd_trace_file("trace.vcd");
    sca_util::sca_trace(trace, sig_livello_acqua, "livello_acqua");
    sca_util::sca_trace(trace, sig_threshold, "threshold");
    sca_util::sca_trace(trace, sig_apertura, "apertura");
    sca_util::sca_trace(trace, sig_comando, "comando");

    // Partenza simulazione
    sc_core::sc_start(COMMON_TIMESTEP * CONTROLLER_ITERATION_THRESHOLD * 100);
    sca_util::sca_close_vcd_trace_file(trace);

    return 0;
}
